# FoodWebsite

I created a food wage website using HTML and CSS, which provides a platform for food lovers to discover new recipes and cooking techniques. With a user-friendly interface and visually appealing design, visitors can easily navigate through the pages and explore various culinary options. Whether you're a beginner or an experienced chef, there's something for everyone on our site. Join our community of food enthusiasts and elevate your cooking game today!


Click hereto see Website !              


https://suraj1849.github.io/FoodWebsite/
